package eu.europa.ec.etrustex.web.persistence.repository.redirect;

import eu.europa.ec.etrustex.web.persistence.entity.redirect.InboxMessageDetailsRedirect;

public interface InboxMessageDetailsRedirectRepository extends MessageRedirectRepository<InboxMessageDetailsRedirect> {
}
