BEGIN
    FOR pr IN ( SELECT DISTINCT up.user_id, g.id, up.email_address, up.name
                FROM ew_user_profile up
                         JOIN ew_group g ON up.group_id = g.parent_id AND up.group_id != 'ROOT'
                         JOIN ew_granted_authority ga ON ga.group_id = g.id AND ga.user_id = up.user_id )
    LOOP
        INSERT INTO ew_user_profile (user_id, group_id, created_date, email_address, name)
        select pr.user_id, pr.id, sysdate, pr.email_address, pr.name
        from dual
        WHERE NOT EXISTS(SELECT *
                         FROM ew_user_profile
                         WHERE (user_id = pr.user_id and group_id = pr.id));
    END LOOP;
END;
