BEGIN
FOR gr IN ( SELECT grp.id FROM ew_group grp WHERE grp.type = 'BUSINESS' AND (SELECT count(id) FROM EW_GROUP_CONFIGURATION WHERE DTYPE = 'RetentionPolicyNotificationGroupConfiguration' and group_id = grp.id) = 0 )

    LOOP
        INSERT INTO EW_GROUP_CONFIGURATION (ID, DTYPE, CREATED_BY, CREATED_DATE, GROUP_ID, ACTIVE, INTEGER_VALUE)
        VALUES ( GROUP_CONFIGURATION_SEQ.NEXTVAL, 'RetentionPolicyNotificationGroupConfiguration', 'SYSTEM', sysdate, gr.id, 0, -1 );
    END LOOP;
END;