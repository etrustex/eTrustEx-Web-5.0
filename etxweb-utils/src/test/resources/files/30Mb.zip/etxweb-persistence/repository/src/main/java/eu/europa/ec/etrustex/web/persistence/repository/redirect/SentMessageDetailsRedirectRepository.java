package eu.europa.ec.etrustex.web.persistence.repository.redirect;

import eu.europa.ec.etrustex.web.persistence.entity.redirect.SentMessageDetailsRedirect;

public interface SentMessageDetailsRedirectRepository extends MessageRedirectRepository<SentMessageDetailsRedirect> {
}
