--------------------------------------------------------
--  SYS_ADMIN Policies
--------------------------------------------------------
INSERT ALL
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','NodeEndpoint','System',sysdate,'System',sysdate,'Allow user to configure Endpoints',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','NodeEndpoint','System',sysdate,'System',sysdate,'Allow user to retrieve Endpoints',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Group','System',sysdate,'System',sysdate,'Allow user to create Group',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('UPDATE','Group','System',sysdate,'System',sysdate,'Allow user to update Group',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','Group','System',sysdate,'System',sysdate,'Allow user to read group',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('DELETE','Group','System',sysdate,'System',sysdate,'Allow user to delete group',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Channel','System',sysdate,'System',sysdate,'Allow user to create Channel',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','GrantedAuthority','System',sysdate,'System',sysdate,'Allow user to create GrantedAuthority',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','ExchangeRule','System',sysdate,'System',sysdate,'Allow user to create ExchangeRule',1,3)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Policy','System',sysdate,'System',sysdate,'Allow user to create Policy',1,3)
SELECT * FROM dual;

--------------------------------------------------------
--  GROUP_ADMIN Policies
--------------------------------------------------------
INSERT ALL
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Group','System',sysdate,'System',sysdate,'Allow user to create Group',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('UPDATE','Group','System',sysdate,'System',sysdate,'Allow user to update Group',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','Group','System',sysdate,'System',sysdate,'Allow user to read group',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('DELETE','Group','System',sysdate,'System',sysdate,'Allow user to delete group',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Channel','System',sysdate,'System',sysdate,'Allow user to create Channel',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','GrantedAuthority','System',sysdate,'System',sysdate,'Allow user to create GrantedAuthority',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','ExchangeRule','System',sysdate,'System',sysdate,'Allow user to create ExchangeRule',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','NodeEndpoint','System',sysdate,'System',sysdate,'Allow user to configure Endpoints',1,2)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','NodeEndpoint','System',sysdate,'System',sysdate,'Allow user to retrieve Endpoints',1,2)
SELECT * FROM dual;

--------------------------------------------------------
--  OPERATOR Policies
--------------------------------------------------------
INSERT ALL
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','Group','System',sysdate,'System',sysdate,'Allow user to read group',1,1)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('DELETE','Attachment','System',sysdate,'System',sysdate,'Allow user delete attachment',1,1)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('CREATE','Message','System',sysdate,'System',sysdate,'Allow user create a new message',1,1)
INTO EW_POLICY ("ACTION",DOMAIN_TYPE,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,DESCRIPTION,GRANTING,ROLE_ID) VALUES
('RETRIEVE','Message','System',sysdate,'System',sysdate,'Allow user to read message and download attachments',1,1)
SELECT * FROM dual;
