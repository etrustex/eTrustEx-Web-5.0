BEGIN
    FOR b IN ( SELECT g.id FROM ew_group g WHERE "TYPE" = 'BUSINESS' )
        LOOP
            INSERT INTO ew_group_configuration (id, dtype, created_date, group_id, boolean_value)
            VALUES (GROUP_CONFIGURATION_SEQ.nextval, 'WindowsCompatibleFilenamesGroupConfiguration', sysdate, b.id, 0);
            INSERT INTO ew_group_configuration (id, dtype, created_date, group_id, string_value)
            VALUES (GROUP_CONFIGURATION_SEQ.nextval, 'ForbiddenExtensionsGroupConfiguration', sysdate, b.id, '');
            INSERT INTO ew_group_configuration (id, dtype, created_date, group_id, integer_value)
            VALUES (GROUP_CONFIGURATION_SEQ.nextval, 'RetentionPolicyGroupConfiguration', sysdate, b.id, -1);
        END LOOP;
END;
