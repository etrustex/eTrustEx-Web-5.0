package eu.europa.ec.etrustex.web.persistence.repository.exchange;

import eu.europa.ec.etrustex.web.persistence.entity.exchange.Channel;
import eu.europa.ec.etrustex.web.persistence.entity.security.Group;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ChannelRepository extends CrudRepository<Channel, Long> {
    Page<Channel> findByBusinessId(Long businessId, Pageable pageable);

    int countByBusinessId(Long businessId);

    boolean existsByBusinessIdAndName(Long businessId, String name);

    Channel findByBusinessIdAndName(Long businessId, String name);

    Channel findFirstByAuditingEntityModifiedByOrderByAuditingEntityModifiedDateDesc(String modifiedBy);
    List<Channel> findByBusinessIdAndDefaultChannelIsTrue(Long businessId);

    void deleteByBusiness(Group business);
}
