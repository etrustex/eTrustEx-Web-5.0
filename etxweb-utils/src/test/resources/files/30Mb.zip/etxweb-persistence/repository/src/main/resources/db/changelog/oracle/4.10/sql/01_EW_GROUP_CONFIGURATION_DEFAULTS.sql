BEGIN
    FOR b IN ( SELECT g.id FROM ew_group g WHERE "TYPE" = 'BUSINESS' )
        LOOP
            INSERT INTO ew_group_configuration (id, dtype, created_date, group_id, string_value)
            VALUES (GROUP_CONFIGURATION_SEQ.nextval, 'SplashScreenGroupConfiguration', sysdate, b.id, '');
        END LOOP;
END;
